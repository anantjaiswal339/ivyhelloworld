# Hello 

Web application created using [Ivy](https://github.com/Ivy-Interactive/Ivy). 

Ivy is a web framework for building interactive web applications using C# and .NET.

## Run

```
dotnet watch
```

## Deploy

```
ivy deploy
```